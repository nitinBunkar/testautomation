package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

	
	 WebDriver driver;

	    By email = By.id("email");
	    By password = By.id("pass");
	    By signInBtn = By.id("send2");

	    public LoginPage(WebDriver driver) {
	        this.driver = driver;
	    }

	    public void enterEmail(String emailText) {
	        driver.findElement(email).sendKeys(emailText);
	    }

	    public void enterPassword(String passwordText) {
	        driver.findElement(password).sendKeys(passwordText);
	    }

	    public void clickSignIn() {
	        driver.findElement(signInBtn).click();
	    }
}
